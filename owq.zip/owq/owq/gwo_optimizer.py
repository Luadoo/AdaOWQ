import numpy as np
import torch
import copy
from typing import Dict, List, Tuple, Callable, Optional


class GWOOptimizer:
    """
    Grey Wolf Optimizer (GWO) for hyperparameter optimization in PTQ.
    
    Mathematical Formulation:
    -------------------------
    Encircling prey:
        D = |C * X_p(t) - X(t)|
        X(t+1) = X_p(t) - A * D
    where:
        A = 2a * r1 - a
        C = 2 * r2
        a linearly decreases from 2 to 0 over iterations
    
    Hunting (leader update):
        D_alpha = |C1 * X_alpha - X|
        D_beta  = |C2 * X_beta  - X|
        D_delta = |C3 * X_delta - X|
        X1 = X_alpha - A1 * D_alpha
        X2 = X_beta  - A2 * D_beta
        X3 = X_delta - A3 * D_delta
        X(t+1) = (X1 + X2 + X3) / 3
    """
    
    def __init__(
        self,
        param_bounds: Dict[str, Tuple[float, float]],
        n_wolves: int = 8,
        max_iter: int = 15,
        minimize: bool = True,
        seed: int = 42,
        verbose: bool = True
    ):
        """
        Args:
            param_bounds: Dictionary mapping parameter names to (low, high) bounds
                Example: {'ema_decay': (0.9, 0.999), 'percdamp': (0.001, 0.1)}
            n_wolves: Number of search agents (wolves), recommended 5-15
            max_iter: Maximum iterations, recommended 10-20 for 5D problem
            minimize: If True, minimize fitness; if False, maximize
            seed: Random seed
            verbose: Whether to print progress
        """
        self.param_names = list(param_bounds.keys())
        self.dim = len(self.param_names)
        self.bounds = np.array([param_bounds[name] for name in self.param_names])
        self.lb = self.bounds[:, 0]
        self.ub = self.bounds[:, 1]
        
        self.n_wolves = n_wolves
        self.max_iter = max_iter
        self.minimize = minimize
        self.verbose = verbose
        
        np.random.seed(seed)
        torch.manual_seed(seed)
        
        # Initialize wolf positions randomly within bounds
        self.positions = np.random.uniform(
            low=self.lb, high=self.ub, size=(n_wolves, self.dim)
        )
        
        # Initialize alpha, beta, delta positions and fitness
        self.alpha_pos = np.zeros(self.dim)
        self.alpha_score = float('inf') if minimize else -float('inf')
        self.beta_pos = np.zeros(self.dim)
        self.beta_score = float('inf') if minimize else -float('inf')
        self.delta_pos = np.zeros(self.dim)
        self.delta_score = float('inf') if minimize else -float('inf')
        
        # History tracking
        self.convergence_curve = []
        self.best_params_history = []
    
    def _clip_position(self, pos: np.ndarray) -> np.ndarray:
        """Clip position to stay within bounds."""
        return np.clip(pos, self.lb, self.ub)
    
    def _is_better(self, score1: float, score2: float) -> bool:
        """Check if score1 is better than score2."""
        if self.minimize:
            return score1 < score2
        else:
            return score1 > score2
    
    def _update_leaders(self, fitness: np.ndarray):
        """Update alpha, beta, delta based on current fitness values."""
        for i in range(self.n_wolves):
            score = fitness[i]
            
            # Update alpha
            if self._is_better(score, self.alpha_score):
                self.delta_score = self.beta_score
                self.delta_pos = self.beta_pos.copy()
                self.beta_score = self.alpha_score
                self.beta_pos = self.alpha_pos.copy()
                self.alpha_score = score
                self.alpha_pos = self.positions[i].copy()
            # Update beta
            elif self._is_better(score, self.beta_score):
                self.delta_score = self.beta_score
                self.delta_pos = self.beta_pos.copy()
                self.beta_score = score
                self.beta_pos = self.positions[i].copy()
            # Update delta
            elif self._is_better(score, self.delta_score):
                self.delta_score = score
                self.delta_pos = self.positions[i].copy()
    
    def _vector_to_params(self, vec: np.ndarray) -> Dict[str, float]:
        """Convert position vector to parameter dictionary."""
        params = {}
        for i, name in enumerate(self.param_names):
            params[name] = float(vec[i])
        return params
    
    def optimize(
        self,
        fitness_fn: Callable[[Dict[str, float]], float],
        callback: Optional[Callable[[int, Dict[str, float], float], None]] = None
    ) -> Tuple[Dict[str, float], float, List[float]]:
        """
        Run GWO optimization.
        
        Args:
            fitness_fn: Function that takes parameter dict and returns fitness score
            callback: Optional callback(iter, params, fitness) called each iteration
        
        Returns:
            best_params: Best parameter dictionary found
            best_fitness: Best fitness value
            convergence_curve: Fitness history of alpha wolf
        """
        if self.verbose:
            print("=" * 70)
            print("Starting Grey Wolf Optimization (GWO) for PTQ Hyperparameters")
            print(f"Search dimensions: {self.dim}, Wolves: {self.n_wolves}, Iterations: {self.max_iter}")
            print(f"Parameters: {self.param_names}")
            print("=" * 70)
        
        for iter_idx in range(self.max_iter):
            # Evaluate fitness for all wolves
            fitness_scores = np.zeros(self.n_wolves)
            for wolf_idx in range(self.n_wolves):
                params = self._vector_to_params(self.positions[wolf_idx])
                try:
                    fitness_scores[wolf_idx] = fitness_fn(params)
                except Exception as e:
                    print(f"Warning: Wolf {wolf_idx} failed with error: {e}")
                    fitness_scores[wolf_idx] = float('inf') if self.minimize else -float('inf')
            
            # Update alpha, beta, delta leaders
            self._update_leaders(fitness_scores)
            
            # Record convergence
            self.convergence_curve.append(self.alpha_score)
            best_params = self._vector_to_params(self.alpha_pos)
            self.best_params_history.append(best_params)
            
            # Linear decrease of a from 2 to 0
            a = 2 - iter_idx * (2 / self.max_iter)
            
            # Update positions of all wolves
            for wolf_idx in range(self.n_wolves):
                for dim_idx in range(self.dim):
                    # Generate random coefficients
                    r1 = np.random.random()
                    r2 = np.random.random()
                    
                    # Alpha wolf guidance
                    A1 = 2 * a * r1 - a
                    C1 = 2 * r2
                    D_alpha = abs(C1 * self.alpha_pos[dim_idx] - self.positions[wolf_idx, dim_idx])
                    X1 = self.alpha_pos[dim_idx] - A1 * D_alpha
                    
                    # Beta wolf guidance
                    r1 = np.random.random()
                    r2 = np.random.random()
                    A2 = 2 * a * r1 - a
                    C2 = 2 * r2
                    D_beta = abs(C2 * self.beta_pos[dim_idx] - self.positions[wolf_idx, dim_idx])
                    X2 = self.beta_pos[dim_idx] - A2 * D_beta
                    
                    # Delta wolf guidance
                    r1 = np.random.random()
                    r2 = np.random.random()
                    A3 = 2 * a * r1 - a
                    C3 = 2 * r2
                    D_delta = abs(C3 * self.delta_pos[dim_idx] - self.positions[wolf_idx, dim_idx])
                    X3 = self.delta_pos[dim_idx] - A3 * D_delta
                    
                    # Update position as average of three leaders
                    self.positions[wolf_idx, dim_idx] = (X1 + X2 + X3) / 3
                
                # Clip to bounds
                self.positions[wolf_idx] = self._clip_position(self.positions[wolf_idx])
            
            # Progress printing
            if self.verbose:
                print(f"Iter {iter_idx+1:02d}/{self.max_iter:02d} | "
                      f"Best: {self.alpha_score:.4f} | "
                      f"Params: {', '.join([f'{k}={v:.4f}' for k,v in best_params.items()])}")
            
            # Callback
            if callback is not None:
                callback(iter_idx, best_params, self.alpha_score)
        
        if self.verbose:
            print("=" * 70)
            print("GWO Optimization Complete!")
            print(f"Best fitness: {self.alpha_score:.4f}")
            print(f"Best parameters:")
            for k, v in best_params.items():
                print(f"  {k}: {v:.6f}")
            print("=" * 70)
        
        return best_params, self.alpha_score, self.convergence_curve


def create_ptq_param_bounds(
        ema_decay_range: Tuple[float, float] = (0.9, 0.999),
        q_ema_decay_range: Tuple[float, float] = (0.99, 0.9999),
        fisher_mix_range: Tuple[float, float] = (0.0, 1.0),
        percdamp_range: Tuple[float, float] = (0.001, 0.1),
        n_out_scale_range: Tuple[float, float] = (0.8, 1.2),
        include_fisher: bool = True
) -> Dict[str, Tuple[float, float]]:
    """
    Create parameter bounds dictionary for PTQ hyperparameter optimization.
    
    Args:
        ema_decay_range: (low, high) for Hessian EMA decay
        q_ema_decay_range: (low, high) for Q_ema decay
        fisher_mix_range: (low, high) for Fisher information mixing weight
        percdamp_range: (low, high) for Hessian damping percentage
        n_out_scale_range: (low, high) for outlier count scaling factor
        include_fisher: Whether to include fisher_mix parameter
    
    Returns:
        Dictionary of parameter bounds
    """
    bounds = {
        'ema_decay': ema_decay_range,
        'q_ema_decay': q_ema_decay_range,
        'percdamp': percdamp_range,
        'n_out_scale': n_out_scale_range
    }
    if include_fisher:
        bounds['fisher_mix'] = fisher_mix_range
    return bounds
