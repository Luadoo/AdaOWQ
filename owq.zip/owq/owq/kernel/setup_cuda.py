from setuptools import setup, Extension
from torch.utils import cpp_extension

extra_compile_args = {
    "cxx": [
        "-g", 
        "-O3", 
        "-fopenmp", 
        "-lgomp", 
        "-std=c++17",
    ],
    "nvcc": [
        "-O3", 
        "-std=c++17",
        "--expt-relaxed-constexpr",
        "--expt-extended-lambda",
        "--use_fast_math",
        "--threads=8",
        # 添加多架构支持
        "-gencode=arch=compute_80,code=sm_80",    # A100
        "-gencode=arch=compute_86,code=sm_86",    # RTX 30系列
        "-gencode=arch=compute_89,code=sm_89",    # RTX 40系列
        "-gencode=arch=compute_90,code=sm_90",    # H100
        "-gencode=arch=compute_120,code=sm_120",  # RTX 50系列（Blackwell）
    ],
}

setup(
    name='owq_cuda',
    ext_modules=[cpp_extension.CUDAExtension(
        name = 'owq_cuda', 
        sources = ['owq_cuda.cpp', 'gemv.cu', 'dequant.cu'],
        extra_compile_args=extra_compile_args,
    )],
    cmdclass={'build_ext': cpp_extension.BuildExtension},
    install_requires = ["torch"],
)