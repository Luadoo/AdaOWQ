import math
import time

import torch
import torch.nn as nn
import transformers

from .quant import *

torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False

class GPTQ_OWQ:
    def __init__(self, layer, n_out):
        self.layer = layer
        self.dev = self.layer.weight.device
        W = layer.weight.data.clone()

        if isinstance(self.layer, nn.Conv2d):
            W = W.flatten(1)
        if isinstance(self.layer, transformers.Conv1D):
            W = W.t()

        self.rows = W.shape[0]
        self.columns = W.shape[1]
        self.H = torch.zeros((self.columns, self.columns), device=self.dev)
        self.nsamples = 0

        self.n_out = n_out
        self.n_nonout = W.shape[1] - n_out
        self.owq = n_out > 0
        self.out_quantizer = None
        self.ids = None

        # --- Fisher-related containers ---
        # empirical fisher per input column (same length as columns)
        self.fisher = torch.zeros(self.columns, device=self.dev)
        self.fisher_nsamples = 0

    def add_batch(self, inp, out):
        if len(inp.shape) == 2:
            inp = inp.unsqueeze(0)
        tmp = inp.shape[0]
        if isinstance(self.layer, nn.Linear) or isinstance(self.layer, transformers.Conv1D):
            if len(inp.shape) == 3:
                inp = inp.reshape((-1, inp.shape[-1]))
            inp = inp.t()
        if isinstance(self.layer, nn.Conv2d):
            unfold = nn.Unfold(
                self.layer.kernel_size,
                dilation=self.layer.dilation,
                padding=self.layer.padding,
                stride=self.layer.stride
            )
            inp = unfold(inp)
            inp = inp.permute([1, 0, 2])
            inp = inp.flatten(1)

        self.H *= self.nsamples / (self.nsamples + tmp)
        self.nsamples += tmp
        inp = math.sqrt(2 / self.nsamples) * inp.float()
        self.H += inp.matmul(inp.t())

    def compute_empirical_fisher(self, model, dataloader, loss_fn=None, device=None, max_batches=None, verbose=False):
        """
        Estimate empirical Fisher diagonal for this layer's *input columns*.
        - model: full model containing this layer (in eval mode recommended)
        - dataloader: yields inputs (or (inputs, targets)) for forward. Use calibration data.
        - loss_fn: callable(outputs, targets) -> scalar loss; if None uses logits.pow(2).sum() as proxy
        - device: device to run on (defaults to layer device)
        - max_batches: max number of batches to sample (None = all)
        Notes:
        - This runs backward to collect grad wrt layer input (empirical fisher approximation).
        - It registers forward/backward hooks on self.layer; removes them at the end.
        - The resulting self.fisher is mean-aggregated over sampled activation rows.
        """
        model.eval()
        device = device or self.dev
        hook_handles = []
        act_holder = {'act': None, 'grad': None}

        # forward hook: capture *input* activation to the layer (detach and require grad for backward)
        def forward_hook(module, inp, out):
            # inp may be a tuple; take first (typical)
            a = inp[0].detach().to(device)
            # keep a copy that requires grad so we can get grad wrt activation
            a = a.requires_grad_(True)
            act_holder['act'] = a
            # do not modify actual forward pass
            return None

        # backward hook: capture grad wrt the input activation
        def backward_hook(module, grad_in, grad_out):
            # grad_in[0] corresponds to grad wrt input activation (if present)
            if grad_in and grad_in[0] is not None:
                act_grad = grad_in[0].detach().to(device)
                act_holder['grad'] = act_grad

        # register hooks
        try:
            hook_handles.append(self.layer.register_forward_hook(forward_hook))
            # register_full_backward_hook is available in newer PyTorch; fall back if not
            if hasattr(self.layer, "register_full_backward_hook"):
                hook_handles.append(self.layer.register_full_backward_hook(backward_hook))
            else:
                hook_handles.append(self.layer.register_backward_hook(backward_hook))
        except Exception:
            # If hooks cannot be registered, raise informative error
            for h in hook_handles:
                try:
                    h.remove()
                except Exception:
                    pass
            raise RuntimeError("Failed to register hooks on layer for fisher computation.")

        # reset fisher accumulators
        self.fisher.zero_()
        self.fisher_nsamples = 0
        batches = 0

        for batch in dataloader:
            if max_batches is not None and batches >= max_batches:
                break
            batches += 1

            # handle dataloader output formats
            if isinstance(batch, (list, tuple)) and len(batch) >= 2:
                inputs, targets = batch[0].to(device), batch[1].to(device)
            else:
                inputs, targets = batch.to(device), None

            # forward
            outputs = model(inputs)

            # choose proxy loss if none provided
            if loss_fn is None:
                if isinstance(outputs, (tuple, list)):
                    logits = outputs[0]
                else:
                    logits = outputs
                loss = logits.pow(2).sum()
            else:
                loss = loss_fn(outputs, targets)

            # backward to capture grad wrt activation
            model.zero_grad(set_to_none=True)
            loss.backward(retain_graph=False)

            a = act_holder.get('act', None)
            g = act_holder.get('grad', None)
            if a is None or g is None:
                # this batch didn't pass through the layer or gradient unavailable
                act_holder['act'] = None
                act_holder['grad'] = None
                continue

            # Make shapes consistent with how add_batch expects columns:
            # For Linear / Conv1D, add_batch did inp -> reshape(-1, in_features) then .t()
            act = a.detach()
            grad_act = g.detach()
            # collapse spatial/time dims if present: merge first dims except last feature dim
            if act.dim() >= 3:
                # e.g., [B, L, C] -> [B*L, C]
                act = act.reshape(-1, act.shape[-1])
            if grad_act.dim() >= 3:
                grad_act = grad_act.reshape(-1, grad_act.shape[-1])

            # empirical Fisher approx: accumulate sum of squared gradients per input column
            # grad_act shape: [N_samples, in_features]
            if grad_act.numel() == 0:
                act_holder['act'] = None
                act_holder['grad'] = None
                continue

            # sum of squared gradients over samples -> per-column
            per_col = (grad_act ** 2).sum(dim=0).to(self.dev)  # shape [in_features]
            # convert per_col to match self.columns (should align)
            if per_col.numel() != self.columns:
                # attempt transpose variant (for Conv1D transposed weights)
                # but safer to raise to signal mismatch
                # fallback: resize or trim/pad (but quieter would hide issues). Here, raise informative error.
                for h in hook_handles:
                    try:
                        h.remove()
                    except Exception:
                        pass
                raise RuntimeError(f"Fisher per-column size mismatch: got {per_col.numel()} expected {self.columns}. Check layer input shaping.")

            self.fisher += per_col
            self.fisher_nsamples += grad_act.shape[0]

            # clear holders for next batch
            act_holder['act'] = None
            act_holder['grad'] = None

        # finalize normalization
        if self.fisher_nsamples > 0:
            self.fisher /= float(self.fisher_nsamples)

        # remove hooks
        for h in hook_handles:
            try:
                h.remove()
            except Exception:
                pass

        if verbose:
            print("Computed empirical fisher diag for layer. nsamples:", self.fisher_nsamples)

        return self.fisher.clone()

    def hessian_sorting(self, actorder=False, frob_norm=None, fisher_diag=None, combine_fn='mul'):
        """
        Extended hessian_sorting:
        - If fisher_diag is provided (tensor with length self.columns), combine it with diag(H) to
          form a composite score for column importance. combine_fn: 'mul' (default), 'add', or 'weighted'.
        - Returns indices of the selected out-columns (sorted) as int32 tensor (same as original).
        - Sets self.ids to reorder columns: [weak_cols..., strong_cols...]
        """
        H = self.H

        if not self.owq:
            if actorder:
                self.ids = torch.argsort(torch.diag(H), descending=True)
            return torch.tensor([])

        temp_mask = torch.full([self.columns], True, device=self.dev)

        H_diag = torch.diag(H).clone()
        if frob_norm is not None:
            H_diag = H_diag * frob_norm.to(self.dev)

        if fisher_diag is not None:
            fisher_diag = fisher_diag.to(self.dev)
            # normalize to avoid scale mismatch
            Hd = H_diag / (H_diag.max().clamp(min=1e-12))
            Fd = fisher_diag / (fisher_diag.max().clamp(min=1e-12))
            if combine_fn == 'mul':
                score = Hd * Fd
            elif combine_fn == 'add':
                score = Hd + Fd
            else:  # 'weighted' default weight 0.5/0.5
                score = 0.5 * Hd + 0.5 * Fd
        else:
            score = H_diag

        descending_ids = torch.argsort(score, descending=True)

        temp_mask[descending_ids[:self.n_out]] = False
        if actorder:
            ids = torch.cat([descending_ids[self.n_out:], descending_ids[:self.n_out]])
        else:
            ids = torch.cat([torch.arange(self.columns, device=self.dev)[temp_mask], descending_ids[:self.n_out]])

        self.ids = ids
        return torch.sort(descending_ids[:self.n_out])[0].to(torch.int32)

    def allocate_bits_by_score(self, score_tensor, method='percentile', top_percent=0.2, threshold=None, verbose=False):
        """
        Example helper: allocate bits per input column from a per-column score (higher => more sensitive).
        - score_tensor: 1D tensor length self.columns (e.g., self.fisher or combined score)
        - method:
            - 'percentile': top_percent fraction get 4-bit, others get 3-bit
            - 'threshold': use threshold param to select 4-bit
        Returns:
            bits: torch.IntTensor of shape [self.columns] with values in {3,4} (example)
        Note:
        - You can change values to other bit widths or mapping as needed.
        """
        score = score_tensor.to(self.dev).float()
        n = score.numel()
        if method == 'percentile':
            k = max(1, int(n * float(top_percent)))
            descending = torch.argsort(score, descending=True)
            bits = torch.full((n,), 3, dtype=torch.int32, device=self.dev)
            bits[descending[:k]] = 4
        elif method == 'threshold':
            if threshold is None:
                raise ValueError("threshold must be provided for method='threshold'")
            bits = torch.where(score >= float(threshold), torch.tensor(4, device=self.dev), torch.tensor(3, device=self.dev)).to(torch.int32)
        else:
            raise ValueError("Unsupported method for allocate_bits_by_score")

        if verbose:
            print(f"allocate_bits_by_score: total columns={n}, 4-bit count={(bits==4).sum().item()}")
        return bits

    def fasterquant(
        self, blocksize=128, percdamp=.01, groupsize=-1, actorder=False
    ):
        W = self.layer.weight.data.clone()
        if isinstance(self.layer, nn.Conv2d):
            W = W.flatten(1)
        if isinstance(self.layer, transformers.Conv1D):
            W = W.t()
        W = W.float()

        tick = time.time()

        if actorder or self.owq:
            if self.ids is None:
                raise RuntimeError("IDs not set. Call hessian_sorting(...) before fasterquant when using owq/actorder.")
            W = W[:, self.ids]
            self.H = self.H[self.ids][:, self.ids]

        # find quant params only on weak columns (first self.n_nonout columns)
        self.quantizer.find_params(W[:, :self.n_nonout], weight=True)

        H = self.H
        # remove H to save memory reference; copy kept in H variable
        try:
            del self.H
        except Exception:
            pass
        dead = torch.diag(H) == 0
        H[dead, dead] = 1
        W[:, dead] = 0

        Losses = torch.zeros_like(W)
        Q = torch.zeros_like(W)

        damp = percdamp * torch.mean(torch.diag(H))
        diag = torch.arange(self.columns, device=self.dev)
        H[diag, diag] += damp

        H = torch.linalg.cholesky(H)
        H = torch.cholesky_inverse(H)
        H = torch.linalg.cholesky(H, upper=True)
        Hinv = H

        for i1 in range(0, self.n_nonout, blocksize):
            i2 = min(i1 + blocksize, self.n_nonout)
            count = i2 - i1

            W1 = W[:, i1:i2].clone()
            Q1 = torch.zeros_like(W1)
            Err1 = torch.zeros_like(W1)
            Losses1 = torch.zeros_like(W1)
            Hinv1 = Hinv[i1:i2, i1:i2]

            for i in range(count):
                w = W1[:, i]
                d = Hinv1[i, i]

                if groupsize != -1:
                    if (i1 + i) % groupsize == 0:
                        # recompute quant params for the upcoming group window (keep num param for compatibility)
                        self.quantizer.find_params(W[:, (i1 + i):min((i1 + i + groupsize), (self.columns - self.n_out))], weight=True, num=40)

                q = self.quantizer.quantize(w.unsqueeze(1)).flatten()
                Q1[:, i] = q
                Losses1[:, i] = (w - q) ** 2 / d ** 2

                err1 = (w - q) / d
                W1[:, i:] -= err1.unsqueeze(1).matmul(Hinv1[i, i:].unsqueeze(0))
                Err1[:, i] = err1

            Q[:, i1:i2] = Q1
            Losses[:, i1:i2] = Losses1 / 2

            W[:, i2:] -= Err1.matmul(Hinv[i1:i2, i2:])

        torch.cuda.synchronize()
        print('time %.2f' % (time.time() - tick))
        print('error', torch.sum(Losses).item())

        if actorder or self.owq:
            # keep strong columns (last n_out cols) in high-precision (no quant)
            Q[:, self.n_nonout:] = W[:, self.n_nonout:]
            invids = torch.argsort(self.ids)
            Q = Q[:, invids]

        if isinstance(self.layer, transformers.Conv1D):
            Q = Q.t()

        self.layer.weight.data = Q.reshape(self.layer.weight.shape).to(self.layer.weight.data.dtype)

    def free(self):
        # free stored large buffers
        self.H = None
        try:
            self.Losses = None
        except Exception:
            pass
        self.ids = None
        # keep fisher if user wants to inspect it; do not zero fisher unless explicitly requested
        torch.cuda.empty_cache()
