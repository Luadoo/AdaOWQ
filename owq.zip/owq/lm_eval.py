import argparse
import json
import logging
import os
import time
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from lm_eval import tasks, evaluator, utils
# 引入 OWQ / AdaOWQ 自定义模型包装
from owq.quant import make_quant, QuantLinear
from owq.utils.misc import find_layers

logging.getLogger("openai").setLevel(logging.WARNING)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True, help="/home/xujie-intern/.cache/huggingface/hub/llama3-8b/snapshots/")
    parser.add_argument("--model_args", default="")
    parser.add_argument("--load", type=str, default="", help="/data-model/infer-r1/xujie/my_code/owq/cpt/llama3-8b.pth")
    
    # 新增：自定义评估集路径
    parser.add_argument("--custom_tasks", type=str, default=None, 
                        help="自定义 Task 名称或 JSON 配置路径")
    
    parser.add_argument('--logfile', type=str, default='')
    parser.add_argument("--tasks", default=None)
    parser.add_argument("--num_fewshot", type=int, default=0)
    parser.add_argument("--batch_size", type=str, default=None)
    parser.add_argument("--device", type=str, default=None)
    parser.add_argument("--output_path", default=None)
    parser.add_argument("--limit", type=float, default=None)
    return parser.parse_args()


def main():
    args = parse_args()

    # 1. 动态补充模型参数：如果指定了 AdaOWQ 保存的 checkpoint，传递给 lm-eval 的 hf-causal
    model_args = args.model_args
    if args.load:
        if model_args:
            model_args += f",load={args.load}"
        else:
            model_args = f"load={args.load}"

    # 2. 解析评估任务 (Task)
    if args.tasks is None:
        task_names = tasks.ALL_TASKS
    else:
        task_names = utils.pattern_match(args.tasks.split(","), tasks.ALL_TASKS)

    print(f"Selected Tasks: {task_names}")

    tick = time.time()
    # 3. 运行 evaluator
    results = evaluator.simple_evaluate(
        model="hf-causal",  # 使用 HuggingFace AutoLM 接口
        model_args=f"pretrained={args.model}," + model_args,
        tasks=task_names,
        num_fewshot=args.num_fewshot,
        batch_size=args.batch_size,
        device=args.device,
        limit=args.limit,
    )
    t = time.time() - tick
    
    dumped = json.dumps(results, indent=2)
    print(dumped)

    if args.output_path:
        os.makedirs(os.path.dirname(args.output_path), exist_ok=True)
        with open(args.output_path, "w") as f:
            f.write(dumped)

    print(evaluator.make_table(results))


if __name__ == "__main__":
    main()